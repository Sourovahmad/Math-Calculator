const HomePageContent = [
    {
        title: 'Books',
        img: '"https://s3-img.pixpa.com/com/640/25061/1614454411-257936-how-can-i-help-interior-mockups-pages-turning.gif">',
    },
    {
        title: 'Branding',
        img: '"https://s3-img.pixpa.com/com/640/25061/1615141456-933066-branding-photo.png"',
    },
    {
        title: 'Digital',
        img: '"https://s3-img.pixpa.com/com/640/25061/1614454141-790758-digital-square-gif.gif"',
    },
    {
        title: 'Catalogs',
        img: 'https://s3-img.pixpa.com/com/640/25061/1610211966-703785-romance-covers-diagonal-square.png"',
    },
    {
        title: 'Tradeshow',
        img: '"https://s3-img.pixpa.com/com/640/99640/1603930692-697211-naeyc-2019-01.png">',
    },
    {
        title: 'Packaging',
        img: '"https://s3-img.pixpa.com/com/640/25061/1605559457-799859-private-label-01.png"',
    },
    {
        title: 'Brochure',
        img: '"https://s3-img.pixpa.com/com/640/25061/1607468756-21802-c4l-touringguide-cover-mockup.png" ',
    },
    {
        title: 'Personal Projects',
        img: '"https://s3-img.pixpa.com/com/640/25061/1609863291-155060-train-cards-depthfield.png"',
    },
    {
        title: 'Case Studies',
        img: '"https://s3-img.pixpa.com/com/640/25061/1614288077-433358-branding-square-glasses.png"',
    },
]